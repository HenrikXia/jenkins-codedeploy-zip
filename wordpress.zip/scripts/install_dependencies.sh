#!/bin/bash
sudo yum install -y httpd php72w php72w-common php72w-pdo php72w-mysql php72w-cli php72w-pecl-apcu php72w-bcmath php72w-devel
