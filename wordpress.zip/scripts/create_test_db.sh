#!/bin/bash
echo "create mysql db"
